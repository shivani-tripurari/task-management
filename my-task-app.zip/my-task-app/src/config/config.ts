export const config = {
    firebaseConfig:{
        apiKey: "AIzaSyAlM16nOBn_ybEHw02pI5fL4hEQO6kPUL0",
        authDomain: "task-management-shivani.firebaseapp.com",
        projectId: "task-management-shivani",
        storageBucket: "task-management-shivani.firebasestorage.app",
        messagingSenderId: "381530673019",
        appId: "1:381530673019:web:138e6b4ada1f925df237de",
        measurementId: "G-6J9GD30MY5"
    }
  };